package Data.loader;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import models.Zombie.ArmorDefinition;
import models.Zombie.Behavior.ZombieBehavior;
import models.Zombie.Behavior.ZombieBehaviorFactory;
import models.Zombie.Zombie;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class ZombieLoader {

    private final Map<String, ArmorDefinition> armorRegistry = new HashMap<>();

    private static JsonNode readResourceTree(String classpathResource) throws IOException {
        try (InputStream is = ZombieLoader.class.getResourceAsStream(classpathResource)) {
            if (is == null) {
                throw new IllegalStateException("Missing classpath resource " + classpathResource);
            }
            return new ObjectMapper().readTree(is);
        }
    }

    public void loadArmors(String jsonPath) throws Exception {
        JsonNode root = readResourceTree(jsonPath);

        for (JsonNode entry : root) {
            String alias   = entry.path("aliases").get(0).asText();
            JsonNode d     = entry.path("objdata");

            int     hp         = d.path("BaseHealth").asInt(300);
            boolean metallic   = false;
            boolean passDamage = false;

            for (JsonNode flag : d.path("ArmorFlags")) {
                if (flag.asText().equals("metallic"))   metallic   = true;
                if (flag.asText().equals("passdamage")) passDamage = true;
            }

            List<Float> thresholds = new ArrayList<>();
            for (JsonNode t : d.path("ArmorLayerHealth"))
                thresholds.add((float) t.asDouble());

            ArmorDefinition def = new ArmorDefinition(alias, hp, metallic, passDamage, thresholds);
            armorRegistry.put(alias, def);
            armorRegistry.put(alias + "@ArmorTypes", def);
        }
    }

    public Map<String, Zombie> loadZombies(String jsonPath) throws Exception {
        JsonNode root = readResourceTree(jsonPath);

        Map<String, Zombie> result = new LinkedHashMap<>();

        for (JsonNode entry : root) {
            String alias    = entry.path("aliases").get(0).asText();
            String objclass = entry.path("objclass").asText();
            JsonNode d      = entry.path("objdata");

            Zombie zombie = new Zombie(
                alias,
                (float) d.path("Hitpoints").asDouble(190),
                (float) d.path("Speed").asDouble(0.185),
                (float) d.path("EatDPS").asDouble(100),
                (float) d.path("WavePointCost").asDouble(100),
                d.path("Weight").asInt(1000)
            );

            for (ZombieBehavior behavior : ZombieBehaviorFactory.fromJson(alias, objclass, d, armorRegistry)) {
                zombie.addBehavior(behavior);
            }

            result.put(alias, zombie);
        }

        return result;
    }

    public Map<String, ArmorDefinition> getArmorRegistry() {
        return armorRegistry;
    }
}
