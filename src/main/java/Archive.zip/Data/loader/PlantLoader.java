package Data.loader;

import models.Plant.PlantTag;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PlantLoader {
    private PlantLoader() {}

    public static void load() {
        PlantRegistry.clear();
        loadPlants("/plants.json");
    }

    private static void loadPlants(String path) {
        JSONArray arr = readArray(path);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.getJSONObject(i);
            PlantRegistry.register(new PlantData(
                    obj.getInt("id"), obj.getString("name"), obj.getString("category"),
                    parseTags(obj.optJSONArray("tags")), obj.getInt("cost"), obj.getInt("baseHp"),
                    obj.getInt("damage"), obj.optString("damageExpression", String.valueOf(obj.getInt("damage"))),
                    obj.optString("baseAbility", ""), obj.optString("plantFoodEffect", ""),
                    obj.getDouble("actionInterval"), obj.getDouble("recharge"),
                    obj.optDouble("projectileSpeed", 0.5), obj.optString("lvl2", ""),
                    obj.optString("lvl3", ""), obj.optString("lvl4", ""), parseUpgrades(obj.optJSONArray("upgrades")),
                    requiredString(obj, "cardAssetId"), obj.getString("idlePamPath"),obj.optString("idleClip", "idle"),
                    obj.optString("onPlantFoodDescription"), obj.optString("overallDescription"), obj.optString("funDescription"),
                    parseAnimations(obj), parseProjectiles(obj)
            ));
        }
    }

    private static List<UpgradeData> parseUpgrades(JSONArray arr) {
        List<UpgradeData> result = new ArrayList<>();
        if (arr == null) return result;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject up = arr.getJSONObject(i);
            List<StatModifierData> modifiers = new ArrayList<>();
            JSONArray mods = up.optJSONArray("modifiers");
            if (mods != null) {
                for (int j = 0; j < mods.length(); j++) {
                    JSONObject m = mods.getJSONObject(j);
                    modifiers.add(new StatModifierData(m.getString("stat"), m.getString("operation"),
                            m.getDouble("value")));
                }
            }
            result.add(new UpgradeData(up.getInt("level"), up.optString("description", ""), modifiers));
        }
        return result;
    }

    private static List<PlantTag> parseTags(JSONArray arr) {
        List<PlantTag> tags = new ArrayList<>();
        if (arr == null) return tags;
        for (int i = 0; i < arr.length(); i++) {
            String value = arr.getString(i).trim().toUpperCase().replace('-', '_').replace(' ', '_');
            try { tags.add(PlantTag.valueOf(value)); }
            catch (IllegalArgumentException e) { throw new IllegalStateException("Unknown plant tag: " + value, e); }
        }
        return tags;
    }

    private static JSONArray readArray(String path) {
        try (InputStream is = PlantLoader.class.getResourceAsStream(path)) {
            if (is == null) throw new IllegalStateException("Missing classpath resource " + path);
            return new JSONArray(new String(is.readAllBytes(), StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load " + path, e);
        }
    }

    private static Map<String, PlantAnimationData> parseAnimations(JSONObject obj) {
        JSONObject animations = obj.optJSONObject("animations");
        if (animations == null) {
            return Map.of();
        }
        Map<String, PlantAnimationData> result = new LinkedHashMap<>();
        for (String key : animations.keySet()) {
            JSONObject animation = animations.getJSONObject(key);
            String clip = requiredString(animation, "clip");
            boolean loop = animation.optBoolean("loop", true);
            float duration = (float) animation.optDouble("duration", 0.0);
            result.put(key, new PlantAnimationData(clip, loop, duration));
        }

        return Map.copyOf(result);
    }

    private static Map<String, ProjectileVisualData> parseProjectiles(JSONObject obj) {
        JSONObject projectiles = obj.optJSONObject("projectiles");
        if (projectiles == null) {
            return Map.of();
        }

        Map<String, ProjectileVisualData> result = new LinkedHashMap<>();

        for (String key : projectiles.keySet()) {
            JSONObject projectile = projectiles.getJSONObject(key);
            JSONArray releasesJson = projectile.optJSONArray("releases");
            List<ProjectileReleaseData> releases = new ArrayList<>();

            if (releasesJson != null) {
                for (int i = 0; i < releasesJson.length(); i++) {
                    JSONObject release = releasesJson.getJSONObject(i);
                    releases.add(new ProjectileReleaseData(
                            release.getInt("id"),
                            (float) release.getDouble("time"),
                            (float) release.getDouble("offsetX"),
                            (float) release.getDouble("offsetY")
                    ));
                }
            }

            result.put(key, new ProjectileVisualData(
                    requiredString(projectile, "pamPath"),
                    requiredString(projectile, "clip"),
                    (float) projectile.optDouble("scale", 1.0),
                    List.copyOf(releases)
            ));
        }

        return Map.copyOf(result);
    }

    private static String requiredString(
            JSONObject obj,
            String key
    ) {
        String value = obj.optString(key, "").trim();

        if (value.isEmpty()) {
            throw new IllegalStateException(
                    "Plant '" + obj.optString("name", "unknown")
                            + "' is missing required field '"
                            + key + "'."
            );
        }

        return value;
    }
}
