package controllers;

import Data.database.NewsRepository;
import Data.database.PlantRepository;
import Data.database.ProgressRepository;
import Data.loader.PlantData;
import Data.loader.PlantRegistry;
import models.App;
import models.Result;
import models.User;
import models.enums.Menu;
import models.games.ChapterTheme;
import models.games.Game;
import models.games.Level;
import models.games.LevelType;
import models.games.darkAges.LockedPlantsMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class GameMenuController {
    private static final ChapterTheme[] ADVENTURE_CHAPTERS = {
            ChapterTheme.ANCIENT_EGYPT,
            ChapterTheme.FROSTBITE_CAVES,
            ChapterTheme.BIG_WAVE_BEACH,
            ChapterTheme.DARK_AGES
    };
    private int selectedChapterIndex = -1;
    private int findChapterIndex(String chapterName) {
        if (chapterName == null || chapterName.isBlank()) {
            return -1;
        }
        String requestedName = chapterName.trim();
        for (int i = 0; i < ADVENTURE_CHAPTERS.length; i++) {
            ChapterTheme theme = ADVENTURE_CHAPTERS[i];
            String enumName = theme.name().replace('_', ' ');
            if (theme.getName().equalsIgnoreCase(requestedName)
                    || enumName.equalsIgnoreCase(requestedName)) {
                return i;
            }
        }
        return -1;
    }
    public Result handleEnterChapter(String chapter) {
        if (App.loggedInUser == null) {
            return new Result(false, "You must log in before entering a chapter.\n", null
            );
        }
        int requestedChapterIndex = findChapterIndex(chapter);
        if (requestedChapterIndex == -1) {
            return new Result(
                    false,
                    "Chapter not found.\n" + "Valid chapters:\n"
                            + "- Ancient Egypt\n" + "- Frostbite Caves\n" + "- Big Wave Beach\n" + "- Dark Ages\n",
                    null
            );
        }
        int[] currentProgress = normalizedProgress(App.loggedInUser);
        int unlockedChapterIndex = currentProgress[0] - 1;
        unlockPlantsAvailableThroughProgress(
                App.loggedInUser,
                unlockedChapterIndex,
                currentProgress[1]
        );
        if (requestedChapterIndex > unlockedChapterIndex) {
            ChapterTheme highestUnlockedChapter = ADVENTURE_CHAPTERS[unlockedChapterIndex];
            return new Result(
                    false, "This chapter is locked for you.\n" + "Your highest unlocked chapter is "
                            + highestUnlockedChapter.getName() + ".\n",
                    null
            );
        }
        selectedChapterIndex = requestedChapterIndex;
        ChapterTheme selectedChapter = ADVENTURE_CHAPTERS[selectedChapterIndex];
        int highestUnlockedLevel;

        if (selectedChapterIndex < unlockedChapterIndex) {
            highestUnlockedLevel = selectedChapter.getLevels().size();
        } else {
            highestUnlockedLevel = Math.min(currentProgress[1], selectedChapter.getLevels().size());
        }
        return new Result(
                true,
                selectedChapter.getName()
                        + " selected.\n" + "Unlocked levels: 1 to "
                        + highestUnlockedLevel
                        + ".\n",
                null
        );
    }
    public Result enterLevel(int levelNumber) {
        if (App.loggedInUser == null) {
            return new Result(false, "You must log in before entering a level.\n", null);}
        if (selectedChapterIndex == -1) {
            return new Result(false, "You must select a chapter first.\n", null);
        }
        ChapterTheme selectedChapter = ADVENTURE_CHAPTERS[selectedChapterIndex];
        int numberOfLevels = selectedChapter.getLevels().size();
        if (levelNumber < 1 || levelNumber > numberOfLevels) {
            return new Result(
                    false, "Invalid level number.\n" + selectedChapter.getName()
                            + " has levels 1 to " + numberOfLevels + ".\n", null);
        }
        int[] currentProgress = normalizedProgress(App.loggedInUser);
        int unlockedChapterIndex = currentProgress[0] - 1;
        int unlockedLevelIndex = currentProgress[1] - 1;
        unlockPlantsAvailableThroughProgress(
                App.loggedInUser,
                unlockedChapterIndex,
                currentProgress[1]
        );
        if (selectedChapterIndex > unlockedChapterIndex) {
            return new Result(
                    false, "This chapter is locked for you.\n", null);
        }
        int requestedLevelIndex = levelNumber - 1;
        if (selectedChapterIndex == unlockedChapterIndex && requestedLevelIndex > unlockedLevelIndex) {
            return new Result(
                    false,
                    "Level " + levelNumber + " is locked.\n"
                            + "Your highest unlocked level in "
                            + selectedChapter.getName() + " is Level " + (unlockedLevelIndex + 1) + ".\n",
                    null);
        }
        Level selectedLevel = selectedChapter.getLevels().get(requestedLevelIndex);
        Game newGame = new Game();
        newGame.setCurrentChapterIndex(selectedChapterIndex);
        newGame.setCurrentLevelIndex(requestedLevelIndex);
        App.getInstance().setCurrentGame(newGame);
        if (selectedLevel.type() == LevelType.LOCKED_PLANTS) {
            return lockedPlantsModePrompt(selectedChapter, selectedLevel);
        }
        if (!selectedLevel.type().usesPlantSelection()) {
            return startLevelDirectly(newGame, selectedChapter, selectedLevel);}
        App.getInstance().setCurrentMenu(Menu.PlantSelection_Menu);
        return new Result(
                true, "Entered " + selectedChapter.getName() + " Level "
                        + levelNumber + ".\n" + "You are now in the Plant Selection Menu.\n", null
        );
    }
    private Result lockedPlantsModePrompt(ChapterTheme chapter, Level level) {
        return new Result(
                true,
                "Entered " + chapter.getName() + " Level "
                        + level.levelNumber() + ".\n"
                        + "Choose one Locked Plants mode before plant selection:\n"
                        + "1. Family Lock: one unlocked plant remains available "
                        + "from each restricted family.\n"
                        + "2. Forced Plants: all eight slots are filled and locked.\n",
                null
        );
    }

    public Result chooseLockedPlantsMode(String modeName) {
        Game game = App.getInstance().getCurrentGame();
        if (game == null) {
            return new Result(false, "Enter Dark Ages Level 2 before choosing a mode.\n", null);}
        Level selectedLevel;
        try {selectedLevel = game.getSelectedLevel();
        } catch (IllegalStateException exception) {
            return new Result(false, exception.getMessage() + "\n", null);
        }

        if (selectedLevel.type() != LevelType.LOCKED_PLANTS) {
            return new Result(false, "The selected level is not a Locked Plants level.\n", null);
        }

        LockedPlantsMode mode = LockedPlantsMode.fromCommand(modeName);
        if (mode == null) {
            return new Result(false, "Invalid Locked Plants mode. Use 'family' or 'forced'.\n", null);
        }
        try {
            game.chooseLockedPlantsMode(mode);
        } catch (RuntimeException exception) {
            String message = exception.getMessage();
            if (message == null || message.isBlank()) {
                message = "The mode could not be prepared.";}
            return new Result(
                    false, "Could not prepare Locked Plants mode: " + message + "\n", null);
        }
        App.getInstance().setCurrentMenu(Menu.PlantSelection_Menu);
        if (mode == LockedPlantsMode.FAMILY) {
            return new Result(
                    true,
                    "Family Lock mode selected.\n"
                            + "In the Sun Producer, Shooter, Explosive, Wall-nut, "
                            + "and Strike-through families, only one random unlocked "
                            + "only one random unlocked plant from each family is available.\n"
                            + "You are now in the Plant Selection Menu.\n",
                    null
            );
    }

        StringBuilder forcedPlants = new StringBuilder(
                "Forced Plants mode selected. All eight slots are locked:\n"
        );
        for (PlantData plant : game.getSelectedPlantsForThisGame()) {
            forcedPlants.append("- ").append(plant.name()).append("\n");
        }
        forcedPlants.append("Use 'start game' when you are ready.\n");

        return new Result(true, forcedPlants.toString(), null);
    }

    private Result startLevelDirectly(Game game, ChapterTheme theme, Level level) {
        try {
            game.loadLevel();
            game.start();
            App.getInstance().setCurrentMenu(Menu.GAME_VIEW);
            String firstPlant = game.getConveyorBeltPlants().isEmpty() ? "none" :
                    game.getConveyorBeltPlants().getFirst().name();
            return new Result(
                    true,
                    "Entered " + theme.getName() + " Level " + level.levelNumber() + ".\n"
                            + "so plant selection was skipped.\n"
                            + "First conveyor plant: "
                            + firstPlant + ".\n"
                            + "A new random unlocked plant " + "arrives every 12 seconds.\n",
                    null
            );
        } catch (RuntimeException exception) {
            App.getInstance().setCurrentGame(null);
            App.getInstance().setCurrentMenu(Menu.GAME_MENU);
            String message = exception.getMessage();
            if (message == null || message.isBlank()) {
                message = "The level could not be initialized.";}
            return new Result(false, "Could not start the Conveyor Belt level: " + message + "\n", null);
        }
    }
    public void handleGreenhouse() {
        App.getInstance().setCurrentMenu(Menu.GREENHOUSE_MENU);
    }

    public void handleTravellog() {
        App.getInstance().setCurrentMenu(Menu.TRAVELLOG_MENU);
    }

    public void leaderboard() {
        App.getInstance().setCurrentMenu(Menu.LEADERBOARD_MENU);
    }


    public Result cheatUnlockLevel(String chapterName, int levelNumber) {
        User user = App.getInstance().getLoggedInUser();
        if (user == null) {
            return new Result(false, "You must log in before using this cheat.\n", null);
        }
        int chapterIndex = findChapterIndex(chapterName);
        if (chapterIndex == -1) {
            return new Result(
                    false, "Chapter not found. Valid chapters are Ancient Egypt, "
                            + "Frostbite Caves, Big Wave Beach, and Dark Ages.\n", null
            );
        }
        ChapterTheme chapter = ADVENTURE_CHAPTERS[chapterIndex];
        int levelCount = chapter.getLevels().size();
        if (levelNumber < 1 || levelNumber > levelCount) {
            return new Result(
                    false, chapter.getName() + " has levels 1 to " + levelCount + ".\n", null);
        }
        ProgressRepository progressRepository = new ProgressRepository();
        int[] currentProgress = progressRepository.getCurrentProgress(user.getId());
        int currentChapterIndex = currentProgress[0] - 1;
        int currentLevelNumber = currentProgress[1];
        boolean alreadyUnlocked = chapterIndex < currentChapterIndex || (chapterIndex == currentChapterIndex
                && levelNumber <= currentLevelNumber);
        if (alreadyUnlocked) {
            int unlockedPlantCount = unlockPlantsAvailableThroughProgress(
                    user, currentChapterIndex, currentLevelNumber);
            return new Result(
                    true,
                    "CHEAT: " + chapter.getName() + " Level " + levelNumber + " is already unlocked.\n"
                            + "Missing plant rewards restored: " + unlockedPlantCount + ".\n",
                    null
            );
        }
        boolean saved = progressRepository.saveProgress(user.getId(), chapterIndex + 1, levelNumber);
        if (!saved) {
            return new Result(false, "Could not save the cheated progress.\n", null);
        }
        int unlockedPlantCount = unlockPlantsAvailableThroughProgress(
                user, chapterIndex, levelNumber
        );
        return new Result(
                true,
                "CHEAT: Adventure progress unlocked through "
                        + chapter.getName() + " Level " + levelNumber + ".\n"
                        + "Plant rewards unlocked: " + unlockedPlantCount + ".\n", null
        );
    }

    public Result cheatAdd(int amount, String kind) {
        return new Result(
                false,
                "Account currency cheats are server-backed. Use the graphical debug controls.\n",
                null
        );
    }

    public Result handleEnterMenu(String menuName) {
        if(menuName.equalsIgnoreCase("Collection")){
            App.getInstance().setCurrentMenu(Menu.COLLECTION_MENU);
            return new Result(true,"You are now in the Collection menu.",null);
        }else{
            return new Result(false, "You can only go to the Collection menu!",null);
        }
    }
    private int unlockPlantsAvailableThroughProgress(
            User user,
            int targetChapterIndex,
            int highestUnlockedLevel
    ) {
        List<Integer> plantIds = new ArrayList<>(PlantRegistry.getStarterPlantIds());
        for (int chapterIndex = 0; chapterIndex <= targetChapterIndex; chapterIndex++) {
            ChapterTheme chapter = ADVENTURE_CHAPTERS[chapterIndex];
            plantIds.addAll(PlantRegistry.getChapterPlantIds(chapter));
            int completedLevels = chapterIndex < targetChapterIndex
                    ? chapter.getLevels().size()
                    : Math.max(0, highestUnlockedLevel - 1);
            for (int level = 1; level <= completedLevels; level++) {
                plantIds.addAll(PlantRegistry.getLevelRewardPlantIds(chapter, level));
            }
        }
        Set<Integer> newlyUnlocked = PlantRepository.unlockPlantsAndReturnNew(
                user.getId(),
                plantIds
        );
        createPlantUnlockNews(user, newlyUnlocked);
        return newlyUnlocked.size();
    }

    private void createPlantUnlockNews(User user, Set<Integer> plantIds) {
        NewsRepository newsRepository = new NewsRepository();
        for (int plantId : plantIds) {
            PlantData plant = PlantRegistry.getById(plantId);
            String plantName = plant == null
                    ? "Plant #" + plantId
                    : plant.name();
            newsRepository.createNewsForUser(
                    user.getId(),
                    "New plant unlocked: " + plantName + "."
            );
        }
    }

    private int[] normalizedProgress(User user) {
        ProgressRepository repository = new ProgressRepository();
        int[] raw = repository.getCurrentProgress(user.getId());

        int chapter = Math.max(1, Math.min(ADVENTURE_CHAPTERS.length, raw[0]));
        int levelCount = ADVENTURE_CHAPTERS[chapter - 1].getLevels().size();
        int level = Math.max(1, Math.min(levelCount, raw[1]));

        if (chapter != raw[0] || level != raw[1]) {
            repository.saveProgress(user.getId(), chapter, level);
        }
        return new int[]{chapter, level};
    }
}
