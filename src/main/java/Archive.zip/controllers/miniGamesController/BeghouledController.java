package controllers.miniGamesController;

import controllers.GamingController;
import network.client.ClientNetworkManager;
import models.App;
import models.Board.Board;
import models.Board.Tile;
import models.Plant.Plant;
import models.Result;
import models.enums.Menu;
import models.games.Game;
import models.games.GameState;
import models.games.TerminalMapRenderer;
import models.minigames.MinigameType;
import models.minigames.beghouled.Beghouled;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class BeghouledController extends GamingController {
    public BeghouledController() {
        this(null);
    }

    public BeghouledController(ClientNetworkManager networkManager) {
        super(networkManager);
        this.progressService = new MinigameProgressService(networkManager);
    }

    private final MinigameProgressService progressService;
    private boolean graphicalResultRecorded;
    public Result startStage(int stageNumber) {
        Result access = progressService.checkStageAccess(MinigameType.BEGHOULDED, stageNumber);
        if (!access.success()) {
            return access;
        }
        try {
            Beghouled game = new Beghouled(stageNumber);
            game.loadLevel();
            App.getInstance().setCurrentGame(game);
            App.getInstance().setCurrentMenu(Menu.BEGHOULDED);
            return success(
                "Beghouled stage " + stageNumber + " started.\n"
                    + "Target: to find " + game.getTargetMatches() + " matches.\n"
            );
        } catch (RuntimeException exception) {
            String message = exception.getMessage() == null
                ? "Unknown error."
                : exception.getMessage();
            return failure("Could not start Beghouled: " + message + "\n");
        }
    }
    public void recordGraphicalResult() {

        Beghouled game = activeGame();

        if (graphicalResultRecorded || game == null || game.getGameState() == null || !game.getGameState().isFinished()) {
            return;
        }

        graphicalResultRecorded = true;

        if (game.getGameState().isWon()) {
            progressService.recordWin(
                    MinigameType.BEGHOULDED,
                    game.getStage().getStageNumber()
            );
        }
    }
    public Result swapPlants(int firstX, int firstY, int secondX, int secondY) {
        Beghouled game = activeGame();
        if (game == null) {
            return failure("No active Beghouled game found.\n");
        }
        StringBuilder events = beginEvent(game);
        try {
            Beghouled.SwapOutcome outcome = game.swapPlants(firstX, firstY, secondX, secondY);
            StringBuilder output = new StringBuilder()
                .append("Plants at (").append(firstX).append(", ").append(firstY)
                .append(") and (").append(secondX).append(", ").append(secondY).append(") were swapped.\n")
                .append("Direct matches: ").append(outcome.directMatches()).append("\nCascade matches: ")
                .append(outcome.cascadeMatches()).append("\nSun gained: ").append(outcome.sunGained())
                .append("\nProgress: ").append(outcome.totalMatches()).append('/').append(game.getTargetMatches())
                .append(" matches.\n").append(events);
            if (outcome.boardReset()) {
                output.append("The board had no proper move and was reset.\n");
            }
            return resultAfterPossibleFinish(game, output.toString());
        } catch (IllegalArgumentException | IllegalStateException exception) {
            return failure(exception.getMessage() + "\n");
        }
    }

    public Result upgradePlants(String fromPlant, String toPlant) {
        Beghouled game = activeGame();
        if (game == null) {
            return failure("No active Beghouled game found.\n");
        }
        StringBuilder events = beginEvent(game);
        try {
            Beghouled.UpgradeOutcome outcome = game.upgradePlants(fromPlant, toPlant);
            String output = "Upgraded " + outcome.transformedCount() + " "
                + outcome.fromPlant() + " plant(s) to " + outcome.toPlant() + ".\n"
                + "Cost: " + outcome.cost() + " sun.\n" + "Remaining sun: " + outcome.remainingSun() + ".\n"
                + events;
            return resultAfterPossibleFinish(game, output);
        } catch (IllegalArgumentException | IllegalStateException exception) {
            return failure(exception.getMessage() + "\n");
        }
    }

    public Result advanceTime(int tickCount) {
        Beghouled game = activeGame();
        if (game == null) {
            return failure("No active Beghouled game found.\n");
        }
        if (tickCount <= 0) {
            return failure("Tick count must be positive.\n");
        }

        StringBuilder events = beginEvent(game);
        try {
            game.forward(tickCount);
        } catch (IllegalArgumentException | IllegalStateException exception) {
            return failure(exception.getMessage() + "\n");
        }
        String output = "Game advanced by " + tickCount + " ticks.\n" + events;
        return resultAfterPossibleFinish(game, output);
    }

    public Result showStatus() {
        Beghouled game = activeGame();
        if (game == null) {
            return failure("No active Beghouled game found.\n");
        }
        GameState state = game.getGameState();
        StringBuilder output = new StringBuilder()
            .append("===== BEGHOULDED STATUS =====\n")
            .append("Stage: ").append(game.getStage().getStageNumber()).append("\nDifficulty: ")
            .append(game.getStage().getDifficulty())
            .append("\nTick: ").append(state.getTickCounter())
            .append("\nSun: ").append(state.getSun())
            .append("\nMatches: ").append(game.getCompletedMatches()).append('/').append(game.getTargetMatches())
            .append("\nEndless waves started: ").append(game.getWaveNumber())
            .append("\nLiving zombies: ")
            .append(game.getLivingZombieCount())
            .append("\nCraters: ").append(game.getCraterCount())
            .append("\nLegal swap available: ").append(game.hasAnyLegalSwap() ? "yes" : "no")
            .append("\n\nPlant counts:\n");

        Map<String, Integer> counts = game.getPlantCounts();
        if (counts.isEmpty()) {
            output.append("none\n");
        } else {
            counts.forEach((name, count) -> output
                .append("  ").append(name)
                .append(": ").append(count).append('\n'));
        }
        return success(output.toString());
    }

    public Result showUpgrades() {
        Beghouled game = activeGame();
        if (game == null) {
            return failure("No active Beghouled game found.\n");
        }

        Map<String, Integer> counts = game.getPlantCounts();
        StringBuilder output = new StringBuilder()
            .append("===== BEGHOULDED UPGRADES =====\n")
            .append("Current sun: ")
            .append(game.getGameState().getSun()).append("\n");
        for (Beghouled.UpgradeRule rule : game.getAvailableUpgrades()) {
            output.append(rule.fromPlant())
                .append(" -> ").append(rule.toPlant())
                .append(" | cost: ").append(rule.cost())
                .append(" sun | currently on board: ").append(counts.getOrDefault(rule.fromPlant(), 0))
                .append('\n');
        }
        return success(output.toString());
    }
    private String getBeghouledPlantCode(Plant plant) {
        if (plant == null) {
            return "..";
        }
        String plantName = plant.getName().trim().toLowerCase(Locale.ROOT);
        return switch (plantName) {
            case "peashooter" ->
                "PS";
            case "repeater" ->
                "RP";
            case "mega gatling pea" ->
                "MG";
            case "snow pea" ->
                "SP";
            case "wall-nut" ->
                "WN";
            case "tall-nut" ->
                "TN";
            case "puff-shroom" ->
                "PF";
            case "fume-shroom" ->
                "FS";
            case "cabbage-pult" ->
                "CP";
            case "melon-pult" ->
                "MP";
            case "winter melon" ->
                "WM";
            case "bonk choy" ->
                "BC";
            default -> throw new IllegalStateException(
                "Unknown Beghouled plant: " + plant.getName()
            );
        };
    }
    public Result swapPlantsGraphical(
            int firstX,
            int firstY,
            int secondX,
            int secondY
    ) {
        Beghouled game = activeGame();

        if (game == null) {
            return failure(
                    "No active Beghouled game found.\n"
            );
        }

        StringBuilder events = beginEvent(game);

        try {
            Beghouled.SwapOutcome outcome =
                    game.swapPlants(
                            firstX,
                            firstY,
                            secondX,
                            secondY
                    );

            return new Result(
                    true,
                    events.toString(),
                    outcome
            );

        } catch (
                IllegalArgumentException
                | IllegalStateException exception
        ) {
            return failure(
                    exception.getMessage() + "\n"
            );

        } finally {
            game.getGameState()
                    .setEventLogger(null);
        }
    }
    public Result upgradePlantsGraphical(
            String fromPlant,
            String toPlant
    ) {
        Beghouled game = activeGame();

        if (game == null) {
            return failure(
                    "No active Beghouled game found.\n"
            );
        }

        StringBuilder events = beginEvent(game);

        try {
            Beghouled.UpgradeOutcome outcome =
                    game.upgradePlants(
                            fromPlant,
                            toPlant
                    );

            return new Result(
                    true,
                    events.toString(),
                    outcome
            );

        } catch (
                IllegalArgumentException
                | IllegalStateException exception
        ) {
            return failure(
                    exception.getMessage() + "\n"
            );

        } finally {
            game.getGameState()
                    .setEventLogger(null);
        }
    }
    public Result showMap() {
        Beghouled game = activeGame();
        if (game == null) {
            return failure(
                "No active Beghouled game found.\n"
            );
        }
        GameState state = game.getGameState();
        Map<String, String> plantLegend = buildBeghouledLegend(state);

        String map = TerminalMapRenderer.render(
            "BEGHOULDED MAP",
            List.of(
                "Stage: " + game.getStage().getStageNumber(),
                "Matches: " + game.getCompletedMatches()
                    + "/" + game.getTargetMatches(),
                "Sun: " + state.getSun(),
                "Wave: " + game.getWaveNumber(),
                "Tick: " + state.getTickCounter(),
                "Zombies: " + game.getLivingZombieCount()
            ),
            "",
            state.getBoard(),
            tile -> buildBeghouledMapCell(state, tile),
            lane -> "Row " + (lane + 1),
            lane -> beghouledMowerStatus(state, lane),
            -1
        );

        StringBuilder output = new StringBuilder(map);
        output.append("\nCell: [plant(2)][zombie][loot]\n")
            .append("Plant: ##=crater, ..=empty");
        for (Map.Entry<String, String> entry : plantLegend.entrySet()) {
            output.append(", ")
                .append(entry.getKey())
                .append('=')
                .append(entry.getValue());
        }
        output.append('\n')
            .append("Zombie: Z=zombie, .=none\n")
            .append("Loot: C=coin, D=gem, O=pot, .=none\n");
        return success(output.toString());
    }

    private Map<String, String> buildBeghouledLegend(GameState state) {
        Map<String, String> legend = new TreeMap<>();
        for (Plant plant : state.getBoard().getAllPlants()) {
            legend.put(getBeghouledPlantCode(plant), plant.getName());
        }
        return legend;
    }

    private String buildBeghouledMapCell(
        GameState state,
        Tile tile
    ) {
        String plantCode = tile.isCrater()
            ? "##"
            : getBeghouledPlantCode(tile.getTopPlant());
        char zombieCode = tile.hasZombie(state) ? 'Z' : '.';
        char lootCode = getLootMapSymbol(
            state.getBoard(),
            tile.getLane(),
            tile.getColumn()
        );
        return plantCode + zombieCode + lootCode;
    }

    private String beghouledMowerStatus(GameState state, int lane) {
        return "Mower: "
            + (state.getLawnMowers()[lane].isDestroyed()
                ? "USED"
                : "READY");
    }

    public Result showCurrentMenu() {
        return success("You are now in the Beghouled minigame.\n");
    }

    public Result exitMenu() {
        Beghouled game = activeGame();
        App.getInstance().setCurrentGame(null);
        App.getInstance().setCurrentMenu(Menu.TRAVELLOG_MENU);
        if (game == null) {
            return success("You returned to the Travel Log.\n");
        }
        return success(
            "You left Beghouled stage " + game.getStage().getStageNumber() + " and returned to the Travel Log.\n"
        );
    }

    private StringBuilder beginEvent(Beghouled game) {
        StringBuilder events = new StringBuilder();
        game.getGameState().setEventLogger(message -> {
            events.append(message);
            if (!message.endsWith("\n")) {
                events.append('\n');
            }
        });
        return events;
    }

    private Result resultAfterPossibleFinish(Beghouled game, String message) {
        if (!game.getGameState().isFinished()) {
            return success(message);
        }

        boolean won = game.getGameState().isWon();
        int stageNumber = game.getStage().getStageNumber();
        App.getInstance().setCurrentGame(null);
        App.getInstance().setCurrentMenu(Menu.TRAVELLOG_MENU);

        if (won) {
            String progress = progressService.recordWin(MinigameType.BEGHOULDED, stageNumber);
            return success(
                message
                    + "You completed Beghouled stage "
                    + stageNumber
                    + " and returned to the Travel Log.\n"
                    + progress
            );
        }

        return failure(
            message
                + "You lost Beghouled stage " + stageNumber + " and returned to the Travel Log.\n"
        );
    }

    private Beghouled activeGame() {
        Game game = App.getInstance().getCurrentGame();
        if (game instanceof Beghouled beghouled) {
            return beghouled;
        }
        return null;
    }

    private Result success(String message) {
        return new Result(true, message, null);
    }

    private Result failure(String message) {
        return new Result(false, message, null);
    }
}
