package models.games;

import Data.loader.ZombieRegistry;
import lombok.Getter;
import lombok.Setter;
import models.Board.Tile;
import models.Zombie.Zombie;
import models.Zombie.ZombieType;
import models.items.Wave;
import models.quests.QuestKillSourceType;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.function.IntConsumer;

@Getter
@Setter
public class ZombieWaveManager {
    private static final float BACKWATER_MAX_ZOMBIE_COST = 700f;
    private final GameState gs;
    private final List<ZombieType> allowedAliases; // this chapter zombies
    private final int totalWaves;
    private final float baseDifficulty;        // wave 1
    private final Random random;
    private final boolean endless;
    private final float maxDifficulty;
    private boolean started;
    private boolean tornadoFinalWave = false;
    private IntConsumer onWaveStart = null;    //(graves, water level, icy wind)

    private final List<Wave> waves = new ArrayList<>();
    private Wave currentWave = null;
    private float currentDifficulty = 0f;
    private int firstWaveDelayTicks = 0;

    public ZombieWaveManager(GameState gs, List<ZombieType> allowedAliases,
            int totalWaves, float baseDifficulty
    ) {
        this(gs, allowedAliases, totalWaves, baseDifficulty, true, new Random(), false, Float.MAX_VALUE
        );
    }

    public ZombieWaveManager(GameState gs, List<ZombieType> allowedAliases, int totalWaves,
            float baseDifficulty, boolean autoStart, Random random
    ) {
        this(gs, allowedAliases, totalWaves, baseDifficulty, autoStart, random, false, Float.MAX_VALUE);
    }

    private ZombieWaveManager(
            GameState gs, List<ZombieType> allowedAliases, int totalWaves, float baseDifficulty, boolean autoStart,
            Random random,
            boolean endless,
            float maxDifficulty
    ) {
        this.gs = Objects.requireNonNull(gs, "GameState cannot be null.");
        this.allowedAliases = List.copyOf(
                Objects.requireNonNull(allowedAliases, "Allowed zombies cannot be null."));
        this.random = Objects.requireNonNull(random, "Random cannot be null.");
        if (allowedAliases.isEmpty()) {
            throw new IllegalArgumentException("Allowed zombies cannot be empty.");
        }
        if (!endless && totalWaves <= 0) {
            throw new IllegalArgumentException("Total waves must be positive.");
        }
        if (baseDifficulty <= 0) {
            throw new IllegalArgumentException("Base difficulty must be positive.");
        }

        if (maxDifficulty < baseDifficulty) {
            throw new IllegalArgumentException("Maximum difficulty cannot be less than base difficulty.");
        }

        this.totalWaves = totalWaves;
        this.baseDifficulty = baseDifficulty;
        this.started = autoStart;
        this.endless = endless;
        this.maxDifficulty = maxDifficulty;
    }

    public static ZombieWaveManager endless(GameState state,
            List<ZombieType> allowedZombies, float baseDifficulty, float maxDifficulty, Random random) {
        return new ZombieWaveManager(
                state, allowedZombies, Integer.MAX_VALUE, baseDifficulty, true, random, true,
                maxDifficulty);
    }
    public void start() {
        started = true;
    }


    public void releaseTheNuke() {
        for (Zombie zombie : new ArrayList<>(gs.getZombiesInTheGame())) {
            zombie.killInstantly(gs, QuestKillSourceType.CHEAT);
        }
    }

    public void onTick() {
        if (!started || allWavesSent()) {
            return;
        }
        if (currentWave == null) {
            if (firstWaveDelayTicks > 0) {
                firstWaveDelayTicks--;
                return;
            }
            startNextWave();
            return;
        }
        if (currentWave.isBroken()) {
            startNextWave();
        }
    }

    public boolean allWavesSent() {
        return !endless && waves.size() >= totalWaves;}

    public boolean isLevelCleared() {
        if (endless || !allWavesSent()) {return false;}
        for (Zombie zombie : gs.getZombiesInTheGame()) {
            if (!zombie.isDead()) {
                return false;
            }
        }
        return true;
    }

    public int getCurrentWaveNumber() {
        return currentWave == null ? 0 : currentWave.getWaveNumber();
    }



    private void startNextWave() {
        int number = waves.size() + 1;
        boolean finalWave = !endless && number == totalWaves;
        if (number == 1) {
            currentDifficulty = baseDifficulty;
            gs.getQuestTracker().recordFirstWaveStart(gs.getTickCounter());
        } else if (finalWave) {
            currentDifficulty *= 2f;
        } else {
            currentDifficulty = Math.min(maxDifficulty, currentDifficulty * 1.25f);
        }

        if (endless) {
            gs.logEvent("Endless wave " + number + " started.\n");
        } else if (finalWave) {
            gs.logEvent("The final wave has come.\n");
        } else {
            gs.logEvent("Wave " + number + " started.\n");
        }
        currentWave = new Wave(number, currentDifficulty, finalWave);
        waves.add(currentWave);
        if (onWaveStart != null) {
            onWaveStart.accept(number);}
        spawnZombies(currentWave);
    }

    private void spawnZombies(Wave wave) {
        float remaining = wave.getDifficulty();
        int lanes = gs.getBoard().getLaneCount();
        int spawnColumn = gs.getBoard().getColumnCount() - 1;

        while (true) {
            Zombie zombie = pickAffordableZombie(remaining);
            if (zombie == null) {
                break;
            }

            int lane = random.nextInt(lanes);
            float x = spawnColumn;
            if (wave.isFinalWave() && tornadoFinalWave && random.nextBoolean()) {
                int movedColumns = 1 + random.nextInt(4);
                x -= movedColumns;
                gs.logEvent("A tornado moved " + zombie.getAlias() + " "
                        + movedColumns + " columns forward.\n");
            }

            zombie.setGlowing(random.nextInt(100) < 5);
            zombie.setLane(lane);
            zombie.setX(Math.max(0f, x));
            gs.addZombie(zombie);
            wave.addZombie(zombie);
            remaining -= zombie.getWavePointCost();

            gs.logEvent("Zombie " + zombie.getAlias()
                + " spawned at wave " + wave.getWaveNumber()
                + " in lane " + (lane + 1)
                + " which cost " + zombie.getWavePointCost() + ".\n");
        }
        if (wave.getZombies().isEmpty()) {
            throw new IllegalStateException(
                    "Wave " + wave.getWaveNumber() + " could not spawn any zombie. " + "Its difficulty budget is "
                            + wave.getDifficulty() + "."
            );
        }
    }

    private Zombie pickAffordableZombie(float remainingBudget) {
        List<Zombie> affordable = new ArrayList<>();
        long weightSum = 0;
        for (ZombieType alias : allowedAliases) {
            Zombie template = ZombieRegistry.getTemplate(alias.getAlias());
            if (template == null) {
                continue;
            }
            Zombie candidate = template.copy();
            if (candidate.getWavePointCost() <= remainingBudget) {
                affordable.add(candidate);
                weightSum += Math.max(1, candidate.getWeight());
            }
        }
        if (affordable.isEmpty() || weightSum <= 0) {
            return null;
        }
        long roll = (long) (random.nextDouble() * weightSum);
        for (Zombie candidate : affordable) {
            roll -= Math.max(1, candidate.getWeight());
            if (roll < 0) {
                return candidate;
            }
        }
        return affordable.get(affordable.size() - 1);
    }
    public Zombie spawnZombieFromGrave(Tile graveTile, int waveNumber) {
        if (graveTile == null || !graveTile.hasGrave()) {
            return null;
        }
        Zombie existingZombie = gs.getBoard().getZombieInPosition(graveTile.getLane(), graveTile.getColumn());
        if (existingZombie != null) {
            return null;
        }
        Zombie zombie = pickAffordableZombie(Float.MAX_VALUE);
        if (zombie == null) {
            return null;
        }
        zombie.setLane(graveTile.getLane());
        zombie.setX(graveTile.getColumn());
        zombie.setGlowing(random.nextInt(100) < 5);
        gs.addZombie(zombie);

        if (currentWave != null) {
            currentWave.addZombie(zombie);
        }
        gs.logEvent(
                "Necromancy summoned "
                        + zombie.getAlias()
                        + " from the grave at (" + (graveTile.getColumn() + 1)
                        + ", " + (graveTile.getLane() + 1) + ") during wave "
                        + waveNumber + ".\n"
        );

        return zombie;
    }
    public Zombie spawnZombieFromBackwater(Tile shoreTile, int waveNumber) {
        if (shoreTile == null || !shoreTile.isLowShore() || !shoreTile.isWater()) {
            return null;}
        Zombie existingZombie = gs.getBoard().getZombieInPosition(shoreTile.getLane(), shoreTile.getColumn());
        if (existingZombie != null) {return null;}
        Zombie zombie = pickAffordableZombie(BACKWATER_MAX_ZOMBIE_COST);
        if (zombie == null) {return null;}
        zombie.setLane(shoreTile.getLane());
        zombie.setX(shoreTile.getColumn());
        zombie.setGlowing(random.nextInt(100) < 5);
        gs.addZombie(zombie);
        if (currentWave != null) {
            currentWave.addZombie(zombie);}
        gs.logEvent(
                "Backwater spawned " + zombie.getAlias()
                        + " from below the low shore at ("
                        + (shoreTile.getColumn() + 1) + ", "
                        + (shoreTile.getLane() + 1) + ") during wave "
                        + waveNumber + ".\n"
        );
        return zombie;
    }

}
