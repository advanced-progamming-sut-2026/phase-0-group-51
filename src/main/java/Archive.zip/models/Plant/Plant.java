package models.Plant;

import lombok.Getter;
import lombok.Setter;
import models.Zombie.Zombie;
import models.games.GameState;
import models.projectile.ElementType;

import java.util.List;
@Getter
@Setter
public class Plant {
    private final int id;
    private final String name;
    private final PlantType plantType;
    private int currentHP;
    public static final int MAX_FROST_LEVEL = 3;
    public static final int ICE_MAX_HEALTH = 600;
    private final List<PlantUpgrade> upgrades;
    private final List<PlantTag> plantTags;
    private PlantStats plantStat;
    private int refundableSunCost = 0;
    private int level = 1;
    private int sunPer;
    private boolean pendingSun;
    private float tickFromLastAct;
    private float ticksOfPlantFood;
    // "can't act right now" timer.
    // covers arm delay (Potato Mine)
    // (Chomper), charge-up (Citron, Bowling Bulb), etc.
    private float disabledTicksRemaining;
    private boolean chargeReady = false;
    // plants with limited life span:
    private float lifespanRemaining = -1;
    //for stack plants:
    private int stackCount = 1;
    // for wramp-up plants
    private int growthStage = 0;
    private int ageTicks = 0;
    // removing themselves after acting
    private boolean markedForRemoval = false;
    private int posX;
    private int posY;
    private int frostLevel;
    private int iceHealth;

    // Octopus Zombie binding
    private static final int OCTOPUS_HP = 400;
    private int octopusHP = 0;

    // Wizard sheep transform
    private boolean transformed = false;

    // Shared state for plants whose special behavior needs a small amount of
    // persistent runtime data without introducing one class per plant.
    private final int[] bowlingBulbCooldownTicks = new int[3];
    private boolean hypnoGargantuarPrimed;
    private boolean blueFlame;
    private int blueFlameTicks;
    private boolean autoPlantFoodOnEntry;

    private boolean squashJumping = false;
    private boolean squashLanded;
    private boolean squashDamageApplied;
    private boolean squashFinished;
    private int squashTargetLane = -1;
    private int squashTargetColumn = -1;
    private int squashLandingTicksRemaining;
    private int squashFinishTicksRemaining;
    private Zombie squashTarget;
    private Zombie squashSecondaryTarget;

    @Getter
    private PlantAction lastAction = PlantAction.NONE;

    @Getter
    private long actionSerial = 0;

    @Getter
    private long plantFoodVisualSerial = 0;

    private int damage;

    public Plant(int id, String name, PlantType plantType, PlantStats plantStat,
                 List<PlantUpgrade> upgrades, List<PlantTag> plantTags) {
        this.id        = id;
        this.name      = name;
        this.plantType = plantType;
        this.plantStat = plantStat;
        this.currentHP = plantStat.maxHp();
        this.upgrades  = upgrades;
        this.plantTags = plantTags;
        this.chargeReady = !plantTags.contains(PlantTag.CHARGE);

    }


    public void tick(GameState gameState) {
        if (!squashJumping
                && (isFrozenByIce() || hasOctopus() || isTransformed())) {
            return;
        }
        ageTicks++;
        tickSpecialState();
        plantType.onEveryTick(this, gameState);
        if (disabledTicksRemaining > 0) {
            disabledTicksRemaining--;

            if (disabledTicksRemaining <= 0
                    && hasTag(PlantTag.CHARGE)) {
                chargeReady = true;
            }

            return;
        }
        if (lifespanRemaining >= 0) {
            lifespanRemaining--;
            if (lifespanRemaining <= 0) {
                markedForRemoval = true;
                return;
            }
        }
        tickFromLastAct++;

        if (isOnPlantFood()) {
            plantType.onFoodTick(this, gameState);
            ticksOfPlantFood--;
            if (markedForRemoval) return;
        } else if (canAct(gameState)) {
            plantType.onTick(this, gameState);
        }
    }

    public boolean canAct(GameState gameState) {
        double requiredTicks = plantType.actionIntervalSeconds(this)
                * gameState.getTicksPerSecond();
        if (tickFromLastAct >= requiredTicks) {
            tickFromLastAct = 0;
            return true;
        }
        return false;
    }

    public boolean isOnPlantFood() {
        return ticksOfPlantFood > 0;
    }

    public void feed(GameState gameState) {
        if (markedForRemoval || isDead() || isFrozenByIce() || hasOctopus() || isOnPlantFood()) {
            return;
        }
        plantFoodVisualSerial++;
        plantType.onFeed(this, gameState);
        ticksOfPlantFood = Math.max(
                0,
                plantType.plantFoodDurationTicks(this, gameState)
        );
        if (ticksOfPlantFood > 0 && !markedForRemoval) {
            plantType.onFoodTick(this, gameState);
            ticksOfPlantFood--;
        }
    }

    public void feedForAtLeast(GameState gameState, int durationTicks) {
        feed(gameState);
        int remaining = Math.max(0, durationTicks - 1);
        if (!markedForRemoval && remaining > ticksOfPlantFood) {
            ticksOfPlantFood = remaining;
        }
    }
    public void setLifespanSeconds(double seconds, GameState state) {
        lifespanRemaining = Math.max(0, (float) (seconds * state.getTicksPerSecond()));
    }

    public void resetLifespanSeconds(double seconds, GameState state) {
        setLifespanSeconds(seconds, state);
    }

    public void forceReady(GameState state) {
        tickFromLastAct = (float) (plantType.actionIntervalSeconds(this)
                * state.getTicksPerSecond());
    }

    public void healToFull() {
        currentHP = plantStat.maxHp();
    }

    public void incrementStackCount(int maximum) {
        stackCount = Math.min(maximum, stackCount + 1);
    }

    public boolean hasTemporaryArmor() {
        return currentHP > plantStat.maxHp();
    }

    public void disableFor(float ticks) {
        this.disabledTicksRemaining = ticks;

        if (hasTag(PlantTag.CHARGE)) {
            chargeReady = false;
        }
    }

    public boolean isChargeReady() {
        return chargeReady;
    }

    public void setChargeReady(boolean chargeReady) {
        this.chargeReady = chargeReady;
    }

    public boolean isDisabled() {
        return disabledTicksRemaining > 0;
    }
    public void activatePlantFood(){}

    public boolean hasTag(PlantTag tag) {
        return plantTags.contains(tag);
    }

    public boolean isFrozenByIce() {
        return frostLevel >= MAX_FROST_LEVEL && iceHealth > 0;
    }

    public void addFrostLevel(GameState state, String source) {
        if (markedForRemoval || hasTag(PlantTag.FIRE) || frostLevel >= MAX_FROST_LEVEL) {
            return;
        }
        frostLevel++;
        state.logEvent(name + " frost level increased to " + frostLevel + " from " + source + ".\n");
        if (frostLevel == MAX_FROST_LEVEL) {
            iceHealth = ICE_MAX_HEALTH;
            state.logEvent(name + " at (" + (posX + 1) + ", " + (posY + 1) + ") is completely frozen now.\n");
        }
    }

    public boolean damageIce(int damage, ElementType element, GameState state) {
        if (!isFrozenByIce()) {
            return false;
        }
        if (element == ElementType.FIRE) {
            iceHealth = 0;
        } else {
            iceHealth = Math.max(0, iceHealth - Math.max(0, damage));
        }
        if (iceHealth == 0) {
            melting(state);
        }
        return true;
    }

    public void meltIce(int damage, GameState state) {
        if (!isFrozenByIce()) {
            return;
        }
        iceHealth = Math.max(0, iceHealth - Math.max(0, damage));
        if (iceHealth == 0) {
            melting(state);
        }
    }

    private void melting(GameState state) {
        frostLevel = 0;
        state.logEvent(name + " at (" + (posX + 1) + ", " + (posY + 1) + ") has melted.\n");
    }
    public void levelUp() {
        if (level >= upgrades.size() + 1) return;
        int oldMaxHp = plantStat.maxHp();
        plantStat = upgrades.get(level - 1).apply(plantStat);
        int hpGain = plantStat.maxHp() - oldMaxHp;
        if (hpGain > 0) currentHP += hpGain;
        level++;
    }
    public void takeDamage(int damage){
        this.currentHP = Math.max(0, this.currentHP - Math.max(0, damage));
    }
    public void takeDamage(int damage, GameState gameState){
        if (markedForRemoval || damage <= 0) return;
        if (damageIce(damage, ElementType.NORMAL, gameState)) {
            return;
        }
        if (hasOctopus()) {
            octopusHP = Math.max(0, octopusHP - damage);
            return;
        }
        boolean armorBefore = hasTemporaryArmor();
        this.currentHP = Math.max(0, this.currentHP - damage);
        if (armorBefore && !hasTemporaryArmor() && currentHP > 0) {
            plantType.onArmorBroken(this, gameState);
        }
        if (this.currentHP <= 0) die(gameState);
    }
    public boolean isDead(){
        return currentHP <= 0;
    }
    public void addArmor(int hp){
        this.currentHP += hp;
    }

    public void setBowlingBulbCooldown(int slot, int ticks) {
        if (slot >= 0 && slot < bowlingBulbCooldownTicks.length) {
            bowlingBulbCooldownTicks[slot] = Math.max(0, ticks);
        }
    }

    public int getBowlingBulbCooldown(int slot) {
        if (slot < 0 || slot >= bowlingBulbCooldownTicks.length) {
            return Integer.MAX_VALUE;
        }
        return bowlingBulbCooldownTicks[slot];
    }
    public void startSquashJump(
            Zombie target,
            Zombie secondaryTarget,
            int landingFallbackTicks,
            int finishFallbackTicks
    ) {
        if (target == null) {
            throw new IllegalArgumentException(
                    "Squash jump target cannot be null."
            );
        }

        squashJumping = true;
        squashLanded = false;
        squashDamageApplied = false;
        squashFinished = false;
        squashLandingTicksRemaining = Math.max(
                1,
                landingFallbackTicks
        );
        squashFinishTicksRemaining = Math.max(
                squashLandingTicksRemaining + 1,
                finishFallbackTicks
        );
        squashTarget = target;
        squashSecondaryTarget = secondaryTarget;
        squashTargetLane = target.getLane();
        squashTargetColumn = (int) Math.floor(target.getX());
    }

    public void advanceSquashJump() {
        if (!squashJumping) {
            return;
        }

        if (!squashLanded && squashLandingTicksRemaining > 0) {
            squashLandingTicksRemaining--;
            if (squashLandingTicksRemaining <= 0) {
                squashLanded = true;
            }
        }

        if (!squashFinished && squashFinishTicksRemaining > 0) {
            squashFinishTicksRemaining--;
            if (squashFinishTicksRemaining <= 0) {
                squashFinished = true;
            }
        }
    }

    public void markSquashLanded() {
        if (squashJumping) {
            squashLanded = true;
        }
    }

    public boolean shouldApplySquashDamage() {
        return squashJumping
                && squashLanded
                && !squashDamageApplied;
    }

    public void markSquashDamageApplied() {
        if (squashJumping) {
            squashDamageApplied = true;
        }
    }

    public void finishSquashJump() {
        if (squashJumping) {
        squashFinished = true;
    }
    }

    public void clearSquashJump() {
        squashJumping = false;
        squashLanded = false;
        squashDamageApplied = false;
        squashFinished = false;
        squashTargetLane = -1;
        squashTargetColumn = -1;
        squashLandingTicksRemaining = 0;
        squashFinishTicksRemaining = 0;
        squashTarget = null;
        squashSecondaryTarget = null;
    }

    public void meltCompletely(GameState state) {
        if (frostLevel == 0 && iceHealth == 0) {
            return;
        }
        frostLevel = 0;
        iceHealth = 0;
        state.logEvent(name + " at (" + (posX + 1) + ", "
                + (posY + 1) + ") was warmed and thawed.\n");
    }

    public void activateBlueFlame(int ticks) {
        blueFlame = true;
        blueFlameTicks = Math.max(blueFlameTicks, ticks);
    }

    private void tickSpecialState() {
        for (int i = 0; i < bowlingBulbCooldownTicks.length; i++) {
            if (bowlingBulbCooldownTicks[i] > 0) {
                bowlingBulbCooldownTicks[i]--;
            }
        }
        if (blueFlameTicks > 0) {
            blueFlameTicks--;
            if (blueFlameTicks == 0) {
                blueFlame = false;
            }
        }
    }
    public void signalAction(PlantAction action) {
        lastAction = action;
        actionSerial++;
    }
    public void die(GameState gameState) {
        if (markedForRemoval) return;
        markedForRemoval = true;
        gameState.getQuestTracker().recordPlantLost(this);
        plantType.onDeath(this, gameState);
        gameState.logEvent("Plant " + name + " at (" + (posX + 1) + ", " + (posY + 1) + ") is destroyed.\n");
        gameState.onPlantDestroyed(this);
        gameState.getBoard().removePlant(this);
    }
    public int getDamage() {
        return plantStat.damage();
    }
    public void updateTick(int tick){}
    public void shoot(){}
    public void produceSun(){}
    public void usePlantFood(){}


    public boolean hasOctopus() {
        return octopusHP > 0;
    }

    public void attachOctopus() {
        this.octopusHP = OCTOPUS_HP;
    }
}
