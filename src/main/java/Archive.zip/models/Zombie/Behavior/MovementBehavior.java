package models.Zombie.Behavior;

import lombok.Getter;
import models.Board.Board;
import models.Plant.Plant;
import models.Zombie.Zombie;
import models.games.GameState;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
@Getter
public class MovementBehavior implements PersistableBehavior {
    private static final Random RANDOM = new Random();

    public static final List<String> DODO_FLY_OVER_PLANTS = List.of(
        "iceburg",
        "wallnut",
        "potatomine",
        "primalpotatomine",
        "endurian",
        "cactus",
        "garlic",
        "sweetpotato",
        "explodeonut",
        "pumpkin"
    );

    private final MovementType type;
    private final float extraParam;
    private final List<String> flyOverTargets;

    private boolean submerged = false;          // UNDERGROUND (snorkel)
    private boolean skipEatingThisTick = false; // FLY_OVER (dodo)
    private boolean pianoSpeedApplied = false;  // PIANO_CRUSH

    // Endpoints of the most recent FLY_OVER leap, so the view can play the
    // dodo flight arc synced with the fly animation instead of snapping.
    private float lastJumpFromX;
    private float lastJumpToX;

    public MovementBehavior(MovementType type) {
        this(type, 0, Collections.emptyList());
    }

    public MovementBehavior(MovementType type, float extraParam) {
        this(type, extraParam, Collections.emptyList());
    }

    public MovementBehavior(MovementType type, List<String> targets) {
        this(type, 0, targets);
    }

    MovementBehavior(MovementType type, float extraParam, List<String> targets) {
        this.type = type;
        this.extraParam = extraParam;
        this.flyOverTargets = targets;
    }

    @Override
    public void onTick(Zombie zombie, GameState gs) {
        Board board = gs.getBoard();
        int lane = zombie.getLane();
        int col = (int) (zombie.getX());
        skipEatingThisTick = false;

        switch (type) {
            case FLY_OVER -> {
                // Dodo rider
                Plant ahead = board.findNearestPlantInRange(lane, col, 1);
                if (ahead != null && isFlyOverTarget(ahead)) {
                    skipEatingThisTick = true;
                    float fromX = zombie.getX();
                    float toX = Math.max(0f, ahead.getPosX() - 1);
                    lastJumpFromX = fromX;
                    lastJumpToX = toX;
                    zombie.setX(toX);
                }
            }
            case UNDERGROUND -> {
                // Snorkel
                Plant near = board.findNearestPlantInRange(lane, col, 1);
                submerged = board.isWaterTile(lane, col) && near == null;
            }
            case PIANO_CRUSH -> {
                if (!pianoSpeedApplied && extraParam > 0) {
                    zombie.setSpeedMultiplier(extraParam);
                    pianoSpeedApplied = true;
                }
                Plant crushed = board.findNearestPlantInRange(lane, col, 0);
                if (crushed != null) {
                    crushed.takeDamage(crushed.getCurrentHP(),gs);
                }
            }
            default -> {
                // NORMAL_WALK / PROSPECTOR_JUMP need no per-tick handling here.
            }
        }
    }

    private boolean isFlyOverTarget(Plant plant) {
        if (plant.getPlantType().blocksJumping()) {
            return false;
        }
        String name = normalize(plant.getName());
        if (name.isEmpty()) {
            return false;
        }
        for (String target : flyOverTargets) {
            String t = normalize(target);
            if (name.equals(t) || name.startsWith(t) || t.startsWith(name)) {
                return true;
            }
        }
        return false;
    }

    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        String n = s.toLowerCase().replaceAll("[^a-z0-9]", "");
        if (n.equals("iceburg")) {
            n = "iceberglettuce";
        }
        return n;
    }

    public void jumpToBackRow(Zombie zombie) {
        if (type != MovementType.PROSPECTOR_JUMP) {
            return;
        }
        zombie.setX(0);
        if (zombie.getDirection() > 0) {
            zombie.reverseDirection();
        }
    }

    @Override
    public boolean suppressesDefaultEating(Zombie zombie) {
        return type == MovementType.PIANO_CRUSH || skipEatingThisTick;
    }


    public enum MovementType {
        NORMAL_WALK, FLY_OVER, UNDERGROUND, PROSPECTOR_JUMP, PIANO_CRUSH
    }

    @Override
    public String behaviorType() {
        return "MOVEMENT";
    }

    @Override
    public void applyToStatement(Map<String, Object> cols) {
        cols.put("movement_type", getType().name());
        cols.put("movement_param", getExtraParam());
        if (!getFlyOverTargets().isEmpty()) {
            cols.put("movement_targets", String.join(",", getFlyOverTargets()));
        }
    }

    @Override
    public ZombieBehavior copy() {
        return new MovementBehavior(type, extraParam, flyOverTargets);
    }
}
