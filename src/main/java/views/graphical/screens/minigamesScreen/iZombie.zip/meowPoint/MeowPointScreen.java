package views.graphical.screens.minigamesScreen.meowPoint;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import controllers.GamingController;
import graphics.PvzGame;
import models.App;
import models.Board.Board;
import models.Board.Tile;
import models.Result;
import models.games.ChapterTheme;
import models.games.Game;
import models.games.GameState;
import models.meowPoint.ScoreBreakdown;
import models.meowPoint.ScoreTracker;
import models.meowPoint.ScoringRules;
import models.meowPoint.ScoringSunSpawner;
import models.sun.Sun;
import views.graphical.gameplay.board.BoardArea;
import views.graphical.gameplay.board.BoardTransform;
import views.graphical.gameplay.board.BoardView;
import views.graphical.gameplay.manager.PlantViewManager;
import views.graphical.gameplay.manager.ProjectileViewManager;
import views.graphical.gameplay.manager.SunViewManager;
import views.graphical.gameplay.zombie.ZombieAnimationSystem;
import views.graphical.screens.MainMenuScreen;
import views.graphical.screens.minigamesScreen.BaseMinigameScreen;
import views.graphical.ui.StartGameMenuPopup;

public class MeowPointScreen extends BaseMinigameScreen {
    private BoardView boardView;
    private BoardTransform boardTransform;
    private ZombieAnimationSystem zombieAnimationSystem;
    private PlantViewManager plantViewManager;
    private ProjectileViewManager projectileViewManager;
    private SunViewManager sunViewManager;

    private final GamingController gamingController = new GamingController();
    private final ScoreTracker scoreTracker;
    private final ScoringSunSpawner sunSpawner;
    private Label scoreLabel;

    public MeowPointScreen(PvzGame game) {
        super(game, "IMAGE_BACKGROUNDS_CARNIVAL_TEXTURE_LEFT", "IMAGE_BACKGROUNDS_CARNIVAL_TEXTURE", "IMAGE_BACKGROUNDS_CARNIVAL_TEXTURE_RIGHT");
        this.scoreTracker = new ScoreTracker();
        this.sunSpawner = new ScoringSunSpawner(ScoringRules.dailySunSeed(ScoringRules.currentDate()));
        Game currentGame = new Game();
        App.getInstance().setCurrentGame(currentGame);
        BoardArea boardArea = new BoardArea(533f, 62f, 737f, 380f); // مقادیر استاندارد زمین
        this.boardTransform = new BoardTransform(boardArea);
    }

    @Override
    protected void onGameplayStarted() {
        Game currentGame = App.getInstance().getCurrentGame();
        Board board = currentGame.getGameState().getBoard();

        boardView = new BoardView(board, boardTransform);
        boardView.setOnTileClicked(this::handleTileClick);
        worldStage.addActor(boardView);


        zombieAnimationSystem = new ZombieAnimationSystem(game.getPamPlayer(), worldStage, boardTransform, ChapterTheme.ANCIENT_EGYPT);
        plantViewManager = new PlantViewManager(game, boardTransform);
        projectileViewManager = new ProjectileViewManager(game, boardTransform);
        sunViewManager = new SunViewManager(game, boardTransform);

        sunViewManager.setOnSunClicked(this::handleSunClicked);


        worldStage.addActor(plantViewManager);
        worldStage.addActor(projectileViewManager);
        worldStage.addActor(sunViewManager);

        scoreLabel = new Label("MeowPoint: 0", game.getSkin(), "default");
        scoreLabel.setPosition(20, WORLD_HEIGHT - 40);
        uiStage.addActor(scoreLabel);
    }

    @Override
    protected void onGameTick() {
        GameState state = App.getInstance().getCurrentGame().getGameState();

        sunSpawner.onTick(state);
        scoreTracker.observeWaveAndSpawns(state);
        scoreTracker.observeDeathsAndWaveCompletion(state);

        if (scoreLabel != null) {
            scoreLabel.setText("MeowPoint: " + scoreTracker.currentTotal());
        }
    }

    @Override
    public void render(float delta) {

        if (isPlaying() && !isPaused()) {
            GameState state = App.getInstance().getCurrentGame().getGameState();
            if (state != null) {
                zombieAnimationSystem.update(delta, 1f, state.getTickCounter(), state.getZombiesInTheGame());
                plantViewManager.sync(state.getBoard());
                projectileViewManager.sync(state.getBoard().getProjectiles(), 1f);
                sunViewManager.sync(state.getBoard().getActiveSuns(), 1f);
            }
        }


        super.render(delta);
    }

    @Override
    protected void onGameFinished(boolean won) {
        GameState state = App.getInstance().getCurrentGame().getGameState();

        ScoreBreakdown breakdown = scoreTracker.finish(state, won);

        Table resultPopup = new Table();
        resultPopup.setBackground(game.getSkin().newDrawable("white_pixel", new Color(0, 0, 0, 0.8f)));
        resultPopup.pad(30f);

        Label title = new Label(won ? "WINNER!" : "GAME OVER", game.getSkin(), "title");
        Label details = new Label(breakdown.format(), game.getSkin(), "default");

        resultPopup.add(title).padBottom(20).row();
        resultPopup.add(details).row();

        resultPopup.getColor().a = 0f;
        resultPopup.addAction(Actions.fadeIn(1.5f));

        showModal(resultPopup);
    }

    @Override
    protected Actor createStartPopup(Runnable onContinue) {
        return new StartGameMenuPopup(
                game,
                onContinue,
                "MeowPoint Challenge",
                1,
                "Defeat the zombies and earn as many MeowPoints as possible!",
                new String[]{
                        "Zombie Value: Each kill gives 50 points + that zombie's wave cost.",
                        "Quick Kill: Kill a zombie quickly for up to 300 bonus points within 30 seconds.",
                        "Simultaneous Kill: Kill multiple zombies in the same tick to earn extra combo points.",
                        "Fast Wave: Clear each wave quickly for up to 500 bonus points within 60 seconds.",
                        "Garden Preservation: Win with plants, mowers and sun remaining for extra points."
                }
        );
    }
    @Override
    protected void restartMinigame() {
        removeModal();
        Gdx.app.postRunnable(() -> game.showScreen(new MeowPointScreen(game)));
    }

    @Override
    protected void exitMinigame() {
        removeModal();
        Gdx.app.postRunnable(() -> game.showScreen(new MainMenuScreen(game)));
    }

    private void handleTileClick(Tile tile) {
        if (!isPlaying() || isPaused() || tile == null) return;

        int x = tile.getColumn() + 1;
        int y = tile.getLane() + 1;

        var selectedPlant = gameHud.getPlantSlotsBar().getSelectedPlant();
        if (selectedPlant != null) {
            Result result = gamingController.plantPlant(selectedPlant.name(), x, y);
            if (!result.success()) {
                game.notifyError(result.message());
            } else {
                gameHud.getPlantSlotsBar().clearPlantSelection();
            }
        }
    }

    private void handleSunClicked(Sun sun) {
        if (!isPlaying() || isPaused() || sun == null) return;
        GameState state = App.getInstance().getCurrentGame().getGameState();
        state.getBoard().collectSun(sun, state);
    }

    @Override
    public void dispose() {
        if (zombieAnimationSystem != null) zombieAnimationSystem.clear();
        super.dispose();
    }
}
